if video / image = m, false, { blablabla
conn.sendFile(m.chat, cita, 'asupan.mp4', 'Nih kak asupan nya!!', m, false, { contextInfo: { forwardingScore: 999, isForwarded: true }})
m, false, { contextInfo: { forwardingScore: 999, isForwarded: true }})

if button / image with button = m, { blablabla
m, { contextInfo: { forwardingScore: 999, isForwarded: true }})

//@${who.split`@`[0]}        /////@${m.sender.split`@`[0]}

